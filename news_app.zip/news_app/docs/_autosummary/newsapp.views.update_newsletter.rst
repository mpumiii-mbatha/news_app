﻿newsapp.views.update\_newsletter
================================

.. currentmodule:: newsapp.views

.. autofunction:: update_newsletter